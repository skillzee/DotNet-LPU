﻿// See https://aka.ms/new-console-template for more information
using Day4OOPDemo;

Console.WriteLine("Hello, World!");

// Employee e1 = new Employee();
