﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LINQ_ConsoleApp
{
    public class Student
    {
        public int RollNo { get; set; }
        public string Name { get; set; }

        public string Gender { get; set; }

        public int Marks { get; set; }

        public int Fees { get; set; }

    }
}
